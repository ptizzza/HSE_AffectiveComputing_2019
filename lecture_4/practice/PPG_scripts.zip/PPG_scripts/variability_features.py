import numpy as np


hf_upper = 0.4
lf_upper = 0.15
vlf_upper = 0.04
ulf_upper = 0.015
percentile_alpha = 2


def get_hrv(shimmer):
    peaktime, peak_shim_values, hr_sh = shimmer
    hrv = peaktime[:-1], peaktime[1:] - peaktime[:-1]
    return hrv


def normalize_hrv(hrv):
    beat_count = 5
    percent_threshold = 0.4
    peaktime, var = hrv
    normalized_peaktime = peaktime[:beat_count].tolist()
    normalized_var = var[:beat_count].tolist()
    for i in range(beat_count, len(peaktime)):
        prev_average = var[i - beat_count:i].mean()
        if (1. + percent_threshold) * prev_average > var[i] > (1. - percent_threshold) * prev_average:
            normalized_peaktime.append(peaktime[i])
            normalized_var.append(var[i])
    normalized_hrv = np.array(normalized_peaktime), np.array(normalized_var)
    return normalized_hrv


def get_statistic(numbers, kinds=('mean', )):
    statistics = {}
    for kind in kinds:
        if kind == 'mean':
            statistics[kind] = np.mean(numbers)
        elif kind == 'sdnn':
            statistics[kind] = np.std(numbers)
        elif kind == 'cv':
            statistics[kind] = np.std(numbers) / np.mean(numbers)
        elif kind == 'pnn50':
            numbers_diff = numbers[1:] - numbers[:-1]
            statistics[kind] = (numbers_diff > 0.05).mean()
        elif kind == 'rmssd':
            numbers_diff = numbers[1:] - numbers[:-1]
            statistics[kind] = (numbers_diff ** 2).mean() ** 0.5
        else:
            print('Unsuported statistic: {}'.format(kind))
    return statistics


def get_poincare_coordinates(nhrv, percentile_alpha=2):
    n_peaktime, nhrv = nhrv
    nhrv_x = nhrv[1:]
    nhrv_y = nhrv[:-1]

    xlims = np.percentile(nhrv_x, percentile_alpha), np.percentile(nhrv_x, 100 - percentile_alpha)
    ylims = np.percentile(nhrv_y, percentile_alpha), np.percentile(nhrv_y, 100 - percentile_alpha)
    nhrv_x = np.clip(nhrv_x, *xlims)
    nhrv_y = np.clip(nhrv_y, *ylims)

    return nhrv_x, nhrv_y


def get_frequency_auc(frq, Y):
    hf_auc = np.trapz(abs(Y[(lf_upper <= frq) & (frq <= hf_upper)]))
    lf_auc = np.trapz(abs(Y[(vlf_upper <= frq) & (frq <= lf_upper)]))
    vlf_auc = np.trapz(abs(Y[(ulf_upper <= frq) & (frq <= vlf_upper)]))
    ulf_auc = np.trapz(abs(Y[frq <= ulf_upper]))
    return dict(zip(['hf', 'lf', 'vlf', 'ulf'], [hf_auc, lf_auc, vlf_auc, ulf_auc]))


def get_spectral_rr(rr_times, rr_intervals):
    n = len(rr_times)
    frequency = np.fft.fftfreq(n, rr_times[1] - rr_times[0])
    rr_fft = np.fft.fft(rr_intervals)
    positive = (frequency > 0)
    frequency = frequency[positive]
    rr_fft = abs(rr_fft[positive])

    rr_fft[rr_fft > np.percentile(rr_fft, 100 - percentile_alpha)] = np.percentile(rr_fft, 100 - percentile_alpha)
    rr_fft[rr_fft < np.percentile(rr_fft, percentile_alpha)] = np.percentile(rr_fft, percentile_alpha)
    return frequency, (1. / n) * rr_fft ** 2
