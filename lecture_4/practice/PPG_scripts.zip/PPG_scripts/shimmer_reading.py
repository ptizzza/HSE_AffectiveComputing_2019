import os.path as osp

import numpy as np
from scipy import signal


SHIMTIMECONST = 3.049285061519135e-05


def readShimmerCSV(fname, data_col_id):
    t_prev = 0
    timestamps = []
    shimmer = []
    omit = 5
    int_overflows = 0
    with open(fname, 'rt') as fin:
        n = 0
        for line in fin:
            if n >= omit:
                s = line.split()
                if len(s) <= data_col_id:
                    continue
                if n > omit:
                    t_prev = t_cur
                t_cur = int(s[0]) + int_overflows * 2 ** 24
                if n == omit:
                    t_prev = t_cur
                else:
                    if t_cur < t_prev:
                        if t_prev > 2 ** 24 - 1 / SHIMTIMECONST:
                            t_cur, t_prev
                            int_overflows += 1
                            t_cur += 2 ** 24
                        else:
                            continue
                s_prev = s
                timestamps.append(t_cur)
                shimmer.append(float(s[data_col_id].replace(',', '.')))

            n += 1
    time = np.array(timestamps, dtype=float)
    shimmer = np.array(shimmer)
    time -= time[0]
    time = time * SHIMTIMECONST
    fps = 1 / (np.median(time[1:] - time[:-1]))
    return time, shimmer, fps


def get_neighbourhood(t_raw, t, neigh):
    t_min = np.min(t_raw)
    t_max = np.max(t_raw)
    t_count = len(t_raw)
    begin = np.where(t_raw >= t - neigh)[0][0] if t >= t_min + neigh else 0
    end = np.where(t_raw > t + neigh)[0][0] if t < t_max - neigh else t_count
    return begin, end


def b2b_custom(
    t_raw, sh_raw,
    max_neigh=0.3, norm_neigh=1.33,
    norm_threshold=0.6, peak_width=0.3, medfilt_wlen=3,
    need_print=False,
):
    t_sh = []
    peak_shim_values = []

    peaks = signal.find_peaks(sh_raw)[0]
    if need_print:
        print(len(peaks))
    for peak in peaks:
        t = t_raw[peak]
        begin, end = get_neighbourhood(t_raw, t, max_neigh)
        if begin == end:
            continue
        neigh_min = np.min(sh_raw[begin:end])
        neigh_max = np.max(sh_raw[begin:end])
        if sh_raw[peak] < neigh_max:
            continue
        begin, end = get_neighbourhood(t_raw, t, norm_neigh)
        if begin >= end or peak <= begin or peak >= end:
            continue
        if (sh_raw[peak] < min(
            norm_threshold * np.max(sh_raw[begin:peak]) + (1 - norm_threshold) * np.min(sh_raw[begin:peak]),
            norm_threshold * np.max(sh_raw[peak:end]) + (1 - norm_threshold) * np.min(sh_raw[peak:end])
        )):
            continue
        begin, end = get_neighbourhood(t_raw, t, peak_width)
        if begin == end:
            continue
        peak_ids = np.where(sh_raw[begin:end] > neigh_max * 0.98 + neigh_min * 0.02)[0]
        if len(peak_ids) == 0:
            continue
        if need_print:
            print('peak_ids =', peak_ids)
        t_peak = (t_raw[begin:end][peak_ids[0]] + t_raw[begin:end][peak_ids[-1]]) / 2
        peak_shim_values.append(neigh_max)
        if need_print:
            print('t = {}, t_peak = {}'.format(t, t_peak))
        t_sh.append(t_peak)
    t_sh, unique_ind = np.unique(np.asarray(t_sh[1:-1]), return_index=True)
    hr_sh = 60. / (t_sh[1:] - t_sh[:-1])
    hr_sh = signal.medfilt(hr_sh, medfilt_wlen)
    return t_sh[1:], np.asarray(peak_shim_values)[1:][unique_ind][1:], hr_sh


def get_shimmer_from_csv(csv_path, need_print=False, column=3):
    percentile_alpha = 3
    if not osp.exists(csv_path):
        print('Path {} doesn\'t exist.'.format(csv_path))
        return None, None
    t_raw, sh_raw, fps_sh = readShimmerCSV(csv_path, column)
    quantile_sh = np.percentile(sh_raw, 99)
    sh_raw[sh_raw > quantile_sh] = quantile_sh
    quantile_sh = np.percentile(sh_raw, 1)
    sh_raw[sh_raw < quantile_sh] = quantile_sh
    peaktime, peak_shim_values, hr_sh = b2b_custom(t_raw, sh_raw, need_print=need_print)
    if len(hr_sh) == 0:
        return None, None
    if np.abs(hr_sh).max() > 150:
        quantile_sh = min(150, np.percentile(hr_sh, 100 - percentile_alpha))
        hr_sh[hr_sh > quantile_sh] = np.mean(hr_sh[hr_sh < quantile_sh])
        quantile_sh = np.percentile(hr_sh, percentile_alpha)
        hr_sh[hr_sh < quantile_sh] = quantile_sh
    return (t_raw, sh_raw, fps_sh), (peaktime, peak_shim_values, hr_sh)
